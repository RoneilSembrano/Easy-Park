package com.example.easypark;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TueThuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tuesday_thursday_option);
    }
}
